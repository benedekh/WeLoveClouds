package weloveclouds.ecs.api;

/**
 * Created by Benoit on 2016-11-18.
 */
public class KVEcsApiFactory {
    public IKVEcsApi createKVEscApiV1(){
        return null;
    }
}
