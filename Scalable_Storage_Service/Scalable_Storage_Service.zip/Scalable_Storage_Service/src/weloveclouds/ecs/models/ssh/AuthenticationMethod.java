package weloveclouds.ecs.models.ssh;

/**
 * Created by Benoit on 2016-11-17.
 */
public enum AuthenticationMethod {
    PRIVATE_KEY, PASSWORD
}
