package weloveclouds.ecs.models.tasks;

/**
 * Created by Benoit on 2016-11-19.
 */
public enum Status {
    COMPLETED, FAILED, WAITING, RUNNING
}
