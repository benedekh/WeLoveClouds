package weloveclouds.loadbalancer.rest.api.v1.models.Responses;

import weloveclouds.commons.status.ServerStatus;

/**
 * Created by Benoit on 2017-01-23.
 */
public class GetServiceinformationResponse {
    ServerStatus status;

}
